/***********************************************************************
Vczh Library++ 3.0
Developer: �����(vczh)
GacUI Tools::Document Framework Base Implementations

Interfaces:
***********************************************************************/
#ifndef GACUI_TOOLS_DOCUMENTFRAMEWORK_DOCUMENTFRAGMENT
#define GACUI_TOOLS_DOCUMENTFRAMEWORK_DOCUMENTFRAGMENT

#include "..\DocumentFramework.h"
#include "DocumentView.h"

namespace vl
{
	namespace gactools
	{
		class DocumentFragment : public Object, public IDocumentFragment
		{
		private:
			List<ICallback*>							callbacks;
			IDocumentFileType*							ownedFileType;
			IDocumentContainer*							ownedContainer;
			DocumentFragment*							ownedFragment;
			WString										friendlyName;
			List<Ptr<IDocumentFragment>>				subFragments;
			WString										defaultViewTypeId;
			Dictionary<WString, Ptr<DocumentView>>		supportedViews;

		protected:

			const List<ICallback*>&						GetCallbacks();
			void										NotifySaveFragment();
			bool										AddSubFragment(IDocumentFragment* fragment);
			bool										DeleteSubFragment(IDocumentFragment* fragment);
			bool										AddSupportedView(Ptr<DocumentView> view);
			bool										SetDefaultView(Ptr<DocumentView> view);
			DocumentFragment*							GetOwnerFragmentInternal();

		public:
			DocumentFragment(IDocumentFileType* _ownedFileType, IDocumentContainer* _ownedContainer, DocumentFragment* _ownedFragment, const WString& _friendlyName);
			~DocumentFragment();

			virtual void								NotifyUpdateFragment();
			void										NotifyUpdateFragmentAndViews(DocumentView* senderView);
			
			bool										AttachCallback(ICallback* callback)override;
			bool										DetachCallback(ICallback* callback)override;
			IDocumentFileType*							GetOwnedFileType()override;
			IDocumentContainer*							GetOwnedContainer()override;
			IDocumentFragment*							GetOwnedFragment()override;
			vint										GetSubFragmentCount()override;
			IDocumentFragment*							GetSubFragment(vint index)override;
			WString										GetFriendlyName()override;

			vint										GetSupportedViewTypeCount()override;
			WString										GetSupportedViewTypeId(vint index)override;
			bool										IsSupportedViewTypeId(const WString& viewTypeId)override;
			WString										GetDefaultViewTypeId()override;
			IDocumentView*								GetView(const WString& viewTypeId)override;
		};

		class FileDocumentFragment : public DocumentFragment
		{
		private:
			bool							modified;
			WString							currentFilePath;
			
		protected:
			virtual bool					LoadDocumentInternal(const WString& filePath)=0;
			virtual bool					SaveDocumentInternal(const WString& filePath)=0;
		public:
			FileDocumentFragment(IDocumentFileType* _ownedFileType, IDocumentContainer* _ownedContainer, DocumentFragment* _ownedFragment, const WString& _friendlyName, const WString& _filePath);
			~FileDocumentFragment();

			void							NotifyUpdateFragment()override;

			bool							IsStoredInSeparatedFile()override;
			bool							CanSaveSeparately()override;
			bool							CanSaveToAnotherFile()override;
			WString							GetFilePath()override;
			bool							ReloadDocument()override;
			bool							SaveDocument()override;
			bool							SaveDocumentAs(const WString& filePath)override;
			bool							IsModified()override;
			void							SetModified(bool value)override;
		};

		class VirtualDocumentFragment : public DocumentFragment
		{
		public:
			VirtualDocumentFragment(IDocumentContainer* _ownedContainer, DocumentFragment* _ownedFragment, const WString& _friendlyName);
			~VirtualDocumentFragment();

			void							NotifyUpdateFragment()override;

			bool							IsStoredInSeparatedFile()override;
			bool							CanSaveSeparately()override;
			bool							CanSaveToAnotherFile()override;
			WString							GetFilePath()override;
			bool							ReloadDocument()override;
			bool							SaveDocument()override;
			bool							SaveDocumentAs(const WString& filePath)override;
			bool							IsModified()override;
			void							SetModified(bool value)override;
		};
	}
}

#endif