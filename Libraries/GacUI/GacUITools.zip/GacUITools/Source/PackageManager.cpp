#include "PackageManager.h"
#include "ServiceImpl\FileDialogService.h"
#include "ServiceImpl\MessageDialogService.h"

namespace vl
{
	namespace gactools
	{

/***********************************************************************
Helper Functions
***********************************************************************/

		void GetMenuButtonAttributes(Ptr<GuiResource> resource, Ptr<XmlElement> parent, WString& text, Ptr<GuiImageData>& image)
		{
			if(auto textElement=XmlGetElement(parent, L"Text"))
			{
				text=XmlGetValue(textElement);
			}
			if(auto imageElement=XmlGetElement(parent, L"Image"))
			if(auto resourceElement=XmlGetAttribute(imageElement, L"resource"))
			{
				image=resource->GetValueByPath(resourceElement->value.value).Cast<GuiImageData>();
			}
		}

		WString TranslateResourceText(Ptr<GuiResource> resource, WString text, Regex& parameterRegex)
		{
			WString result;
			List<Ptr<RegexMatch>> matches;
			parameterRegex.Cut(text, false, matches);
			FOREACH(Ptr<RegexMatch>, match, matches)
			{
				if(match->Success())
				{
					WString name=match->Groups()[L"name"].Get(0).Value();
					WString value=match->Groups()[L"value"].Get(0).Value();
					if(name==L"resource")
					{
						auto textResource=resource->GetValueByPath(value).Cast<ObjectBox<WString>>();
						if(textResource)
						{
							result+=textResource->Unbox();
						}
					}
				}
				else
				{
					result+=match->Result().Value();
				}
			}
			return result;
		}

/***********************************************************************
EnumeratePackages
***********************************************************************/

		void EnumeratePackages(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages)
		{
			CopyFrom(packages,
				From(resource->GetFolder(L"Packages")->GetItems())
					.Select([](Ptr<GuiResourceItem> item){ return item->GetContent(); })
					.FindType<XmlDocument>()
					.Where([](Ptr<XmlDocument> document){ return document->rootElement->name.value==L"Package"; })
					.Select([](Ptr<XmlDocument> document){ return document->rootElement; })
					);
		}

/***********************************************************************
EnumerateCommands
***********************************************************************/

		void EnumerateCommands(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages, Dictionary<WString, Ptr<DocumentToolstripCommand>>& commands)
		{
			FOREACH(Ptr<XmlElement>, package, packages)
			{
				WString packageId;
				if(auto id=XmlGetAttribute(package, L"id"))
				{
					packageId=id->value.value;
				}
				if(auto commandsElement=XmlGetElement(package, L"Commands"))
				{
					FOREACH(Ptr<XmlElement>, commandElement, XmlGetElements(commandsElement, L"Command"))
					{
						if(auto name=XmlGetAttribute(commandElement, L"id"))
						if(!commands.Keys().Contains(name->value.value))
						{
							Ptr<DocumentToolstripCommand> command=new DocumentToolstripCommand(packageId, name->value.value);
							WString text=L"<Empty-Command-Name>";
							Ptr<GuiImageData> image;
							GetMenuButtonAttributes(resource, commandElement, text, image);
							command->SetText(text);
							command->SetImage(image);
							commands.Add(command->GetCommandId(), command);
						}
					}
				}
			}
		}

/***********************************************************************
EnumerateMenuDefinitions
***********************************************************************/

		void EnumerateMenuDefinitions(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages, Group<WString, ProprityMenuGroup>& existingMenuGroups)
		{
			FOREACH(Ptr<XmlElement>, package, packages)
			{
				// find all single menu items
				if(auto menusElement=XmlGetElement(package, L"Menus"))
				{
					FOREACH(Ptr<XmlElement>, menuElement, XmlGetElements(menusElement, L"Menu"))
					{
						if(auto id=XmlGetAttribute(menuElement, L"id"))
						if(auto parent=XmlGetElement(menuElement, L"Parent"))
						if(auto parentId=XmlGetAttribute(parent, L"id"))
						if(auto priority=XmlGetAttribute(parent, L"priority"))
						{
							Ptr<PackageXmlMenuItem> menuItem=new PackageXmlMenuItem;
							menuItem->id=id->value.value;
							menuItem->definition=menuElement;

							Ptr<PackageXmlMenuGroup> menuGroup=new PackageXmlMenuGroup;
							menuGroup->hasSeparator=false;
							menuGroup->menuItems.Add(menuItem);

							ProprityMenuGroup pair(wtoi(priority->value.value), menuGroup);
							existingMenuGroups.Add(parentId->value.value, pair);
						}
					}
				}

				// find all menu groups
				if(auto groupsElement=XmlGetElement(package, L"Groups"))
				{
					FOREACH(Ptr<XmlElement>, groupElement, XmlGetElements(groupsElement, L"Group"))
					{
						Ptr<PackageXmlMenuGroup> menuGroup=new PackageXmlMenuGroup;
						menuGroup->hasSeparator=true;

						FOREACH(Ptr<XmlElement>, parentElement, XmlGetElements(groupElement, L"Parent"))
						{
							if(auto parentId=XmlGetAttribute(parentElement, L"id"))
							if(auto priority=XmlGetAttribute(parentElement, L"priority"))
							{
								ProprityMenuGroup pair(wtoi(priority->value.value), menuGroup);
								existingMenuGroups.Add(parentId->value.value, pair);
							}
						}

						FOREACH(Ptr<XmlElement>, menuElement, XmlGetElements(groupElement, L"Menu"))
						{
							if(auto id=XmlGetAttribute(menuElement, L"id"))
							{
								Ptr<PackageXmlMenuItem> menuItem=new PackageXmlMenuItem;
								menuItem->id=id->value.value;
								menuItem->definition=menuElement;
								menuGroup->menuItems.Add(menuItem);
							}
						}
					}
				}
			}
		}

/***********************************************************************
BuildMenu/BuildToolbar
***********************************************************************/

		void BuildToolstripObject(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages, GuiToolstripBuilder* rootBuilder, bool forToolbar, const WString& containerName, Dictionary<WString, Ptr<DocumentToolstripCommand>>& commands, Group<WString, ProprityMenuGroup>& existingMenuGroups)
		{
			vint processingMenuItemIndex=-1;
			WString currentParentId=containerName;
			GuiToolstripButton* currentMenuButton=0;
			GuiToolstripBuilder* currentBuilder=0;
			Regex parameterRegex(L"/{(<name>/w+):(<value>[^{}]*)/}");
			List<Ptr<PackageXmlMenuItem>> processingMenuItems;

			FOREACH(Ptr<DocumentToolstripCommand>, command, commands.Values())
			{
				command->SetText(TranslateResourceText(resource, command->GetText(), parameterRegex));
			}

			while(true)
			{
				vint index=existingMenuGroups.Keys().IndexOf(currentParentId);
				if(index!=-1)
				{
					List<Ptr<PackageXmlMenuGroup>> orderedGroups;
					CopyFrom(orderedGroups,
						From(existingMenuGroups.GetByIndex(index))
							.Where([](ProprityMenuGroup p){ return p.value->menuItems.Count()>0; })
							.OrderBy([](ProprityMenuGroup p1, ProprityMenuGroup p2){ return p1.key-p2.key; })
							.Select([](ProprityMenuGroup p){ return p.value; })
						);

					if(orderedGroups.Count()>0)
					{
						GuiToolstripBuilder* currentBuilder=0;
						if(currentMenuButton)
						{
							currentMenuButton->CreateToolstripSubMenu();
							GuiToolstripMenu* menu=currentMenuButton->GetToolstripSubMenu();
							currentBuilder=menu->GetBuilder();
						}
						else
						{
							currentBuilder=rootBuilder;
						}

						bool needSeparator=false;
						bool firstGroup=true;
						FOREACH(Ptr<PackageXmlMenuGroup>, group, orderedGroups)
						{
							if(!firstGroup && (needSeparator || group->hasSeparator))
							{
								currentBuilder->Splitter();
							}
							needSeparator=group->hasSeparator;
							firstGroup=false;

							FOREACH(Ptr<PackageXmlMenuItem>, item, group->menuItems)
							{
								Ptr<GuiToolstripCommand> command;
								WString text=L"<Empty-Menu-Name>";
								Ptr<GuiImageData> image;

								if(auto commandAttribute=XmlGetAttribute(item->definition, L"command"))
								{
									vint index=commands.Keys().IndexOf(commandAttribute->value.value);
									if(index==-1)
									{
										text=L"<Unknown-Command-Id>:"+commandAttribute->value.value;
									}
									else
									{
										command=commands.Values().Get(index);
									}
								}
								else
								{
									GetMenuButtonAttributes(resource, item->definition, text, image);
									text=TranslateResourceText(resource, text, parameterRegex);
								}

								WString appear=L"Button";
								if(currentBuilder==rootBuilder && forToolbar)
								{
									if(auto appearAttribute=XmlGetAttribute(item->definition, L"appear"))
									{
										appear=appearAttribute->value.value;
									}
								}

								if(appear==L"SplitButton")
								{
									if(command)
									{
										currentBuilder->SplitButton(command.Obj(), &item->menuButton);
									}
									else
									{
										currentBuilder->SplitButton(image, text, &item->menuButton);
									}
								}
								else if(appear==L"DropdownButton")
								{
									if(command)
									{
										currentBuilder->DropdownButton(command.Obj(), &item->menuButton);
									}
									else
									{
										currentBuilder->DropdownButton(image, text, &item->menuButton);
									}
								}
								else
								{
									if(command)
									{
										currentBuilder->Button(command.Obj(), &item->menuButton);
									}
									else
									{
										currentBuilder->Button(image, text, &item->menuButton);
									}
								}

								processingMenuItems.Add(item);
							}
						}
					}
				}

				processingMenuItemIndex++;
				if(processingMenuItemIndex>=processingMenuItems.Count())
				{
					break;
				}
				currentParentId=processingMenuItems[processingMenuItemIndex]->id;
				currentMenuButton=processingMenuItems[processingMenuItemIndex]->menuButton;
			}
		}

		void BuildMenu(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages, GuiToolstripMenuBar* menu, const WString& containerName, Dictionary<WString, Ptr<DocumentToolstripCommand>>& commands, Group<WString, ProprityMenuGroup>& existingMenuGroups)
		{
			BuildToolstripObject(resource, packages, menu->GetBuilder(), false, containerName, commands, existingMenuGroups);
		}

		void BuildToolbar(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages, GuiToolstripToolbar* toolbar, const WString& containerName, Dictionary<WString, Ptr<DocumentToolstripCommand>>& commands, Group<WString, ProprityMenuGroup>& existingMenuGroups)
		{
			BuildToolstripObject(resource, packages, toolbar->GetBuilder(), true, containerName, commands, existingMenuGroups);
		}

/***********************************************************************
BuildDialogs
***********************************************************************/

		void BuildDialogs(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages, IFileDialogService* service)
		{
			FOREACH(Ptr<XmlElement>, package, packages)
			{
				Ptr<XmlElement> dialogsElement=XmlGetElement(package, L"Dialogs");
				if(dialogsElement)
				{
					FOREACH(Ptr<XmlElement>, dialogElement, XmlGetElements(dialogsElement, L"Dialog"))
					{
						if(auto id=XmlGetAttribute(dialogElement, L"id"))
						if(auto text=XmlGetElement(dialogElement, L"Text"))
						{
							service->CreateFileDialog(id->value.value, XmlGetValue(text));
						}
					}
				}
			}

			FOREACH(Ptr<XmlElement>, package, packages)
			{
				Ptr<XmlElement> filtersElement=XmlGetElement(package, L"Filters");
				if(filtersElement)
				{
					FOREACH(Ptr<XmlElement>, filterElement, XmlGetElements(filtersElement, L"Filter"))
					{
						if(auto name=XmlGetElement(filterElement, L"Name"))
						if(auto pattern=XmlGetElement(filterElement, L"Pattern"))
						{
							FOREACH(Ptr<XmlElement>, parentElement, XmlGetElements(filterElement, L"Parent"))
							{
								if(auto id=XmlGetAttribute(parentElement, L"id"))
								if(auto priority=XmlGetAttribute(parentElement, L"priority"))
								{
									service->AddDialogItem(id->value.value, XmlGetValue(name), XmlGetValue(pattern), wtoi(priority->value.value));
								}
							}
						}
					}
				}
			}
		}

/***********************************************************************
BuildDialogs
***********************************************************************/

		void LoadLegalDocumentPackages(Ptr<GuiResource> resource, List<Ptr<XmlElement>>& packages)
		{
			SortedList<WString> ids;
			FOREACH(Ptr<XmlElement>, package, packages)
			{
				if(auto id=XmlGetAttribute(package, L"id"))
				{
					ids.Add(id->value.value);
				}
			}

			while(Ptr<DocumentPackageLoader> loader=RetriveDocumentPackageLoader())
			{
				if(ids.Contains(loader->packageId))
				{
					Ptr<IDocumentPackage> package=loader->LoadPackage();
					GetDocumentManager()->RegisterPackage(package);
				}
			}
		}

/***********************************************************************
MainApplicationPackage
***********************************************************************/

		MainApplicationPackage::MainApplicationPackage()
			:mainWindow(0)
		{
		}

		MainApplicationPackage::~MainApplicationPackage()
		{
		}

		void MainApplicationPackage::OnBeforeInit()
		{
			resource=LoadPackageResource();
			EnumeratePackages(resource, packages);
			EnumerateCommands(resource, packages, commands);
			EnumerateMenuDefinitions(resource, packages, existingMenuGroups);
			
			fileDialogService=new FileDialogService;
			BuildDialogs(resource, packages, fileDialogService.Obj());
			GetDocumentManager()->RegisterService(fileDialogService);

			messageDialogService=new MessageDialogService;
			GetDocumentManager()->RegisterService(messageDialogService);
		}

		void MainApplicationPackage::OnAfterInit()
		{
			FOREACH(Ptr<DocumentToolstripCommand>, command, commands.Values())
			{
				IDocumentPackage* package=GetDocumentManager()->GetPackageById(command->GetPackageId());
				if(package)
				{
					package->OnInstallCommand(command.Obj());
				}
			}
		}

		GuiWindow* MainApplicationPackage::GetMainWindow()
		{
			return mainWindow;
		}

		void MainApplicationPackage::SetMainWindow(GuiWindow* window)
		{
			mainWindow=window;
		}

		void MainApplicationPackage::BuildApplicationMenu(GuiToolstripMenuBar* menu, const WString& containerName)
		{
			BuildMenu(resource, packages, menu, containerName, commands, existingMenuGroups);
		}

		void MainApplicationPackage::BuildApplicationToolbar(GuiToolstripToolbar* toolbar, const WString& containerName)
		{
			BuildToolbar(resource, packages, toolbar, containerName, commands, existingMenuGroups);
		}

		MainApplicationPackage* MainApplicationPackage::BeforeInit(Ptr<GuiResource> resource, GuiWindow* mainWindow, const WString& mainApplicationPackageId)
		{
			List<Ptr<XmlElement>> packages;
			EnumeratePackages(resource, packages);
			LoadLegalDocumentPackages(resource, packages);

			MainApplicationPackage* appPackage=dynamic_cast<MainApplicationPackage*>(GetDocumentManager()->GetPackageById(mainApplicationPackageId));
			if(appPackage)
			{
				appPackage->SetMainWindow(mainWindow);
			}
			for(vint i=0;i<GetDocumentManager()->GetPackageCount();i++)
			{
				GetDocumentManager()->GetPackage(i)->OnBeforeInit();
			}

			return appPackage;
		}

		void MainApplicationPackage::AfterInit()
		{
			for(vint i=0;i<GetDocumentManager()->GetPackageCount();i++)
			{
				GetDocumentManager()->GetPackage(i)->OnAfterInit();
			}
		}
	}
}